@echo off
setlocal
set "PSEXE=powershell"
where pwsh >nul 2>nul && set "PSEXE=pwsh"
%PSEXE% -NoProfile -ExecutionPolicy Bypass -File "%~dp0START-GAME.ps1" %*
if errorlevel 1 pause
