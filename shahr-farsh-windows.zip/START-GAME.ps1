# Shahr-e Farsh - local launcher for Windows PowerShell (ASCII only).
#
#  usage:  pwsh -ExecutionPolicy Bypass -File .\START-GAME.ps1
#    (or just double-click START-GAME.cmd)
#
#  - unpacks shahr-farsh-escape.zip (must sit next to this script) into .\shahr-farsh
#  - serves it on http://localhost:8200/ with its own tiny TCP server (no Python, no unzip, no admin)
#  - opens the game in the default browser
#
#  Why not just double-click index.html? The game is an ES module: browsers refuse to load
#  module scripts and assets over file://, so you only get the raw HTML text. It has to be served over http.

param([int]$Port = 8200)

$ErrorActionPreference = 'Stop'
$script:ShowLog = $false
Add-Type -AssemblyName System.IO.Compression.FileSystem

$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$zip  = Join-Path $root 'shahr-farsh-escape.zip'
$web  = Join-Path $root 'shahr-farsh'

if (-not (Test-Path $zip)) {
  # allow running from the folder that already holds an unpacked build
  if (Test-Path (Join-Path $root 'index.html')) { $web = $root }
  elseif (Test-Path (Join-Path $root 'dist\index.html')) { $web = Join-Path $root 'dist' }
  else {
    Write-Host ''
    Write-Host '  shahr-farsh-escape.zip was not found next to this script.' -ForegroundColor Red
    Write-Host "  Put the zip in:  $root" -ForegroundColor Yellow
    Write-Host '  (the other zip, shahr-farsh-source.zip, is the source code - it has to be built with npm first)'
    Write-Host ''
    exit 1
  }
}

if ($web -ne $root -and -not (Test-Path $web)) {
  Write-Host "  Unpacking $zip ..."
  New-Item -ItemType Directory -Path $web | Out-Null
  [System.IO.Compression.ZipFile]::ExtractToDirectory($zip, $web)
  Write-Host "  unpacked to $web"
}
if (-not (Test-Path (Join-Path $web 'index.html'))) {
  Write-Host "  $web has no index.html - delete the folder and run this again." -ForegroundColor Red
  exit 1
}

# ---- MIME types: text as UTF-8, everything else as bytes
$types = @{
  '.html' = 'text/html; charset=utf-8'
  '.htm'  = 'text/html; charset=utf-8'
  '.js'   = 'text/javascript; charset=utf-8'
  '.mjs'  = 'text/javascript; charset=utf-8'
  '.css'  = 'text/css; charset=utf-8'
  '.json' = 'application/json; charset=utf-8'
  '.map'  = 'application/json; charset=utf-8'
  '.txt'  = 'text/plain; charset=utf-8'
  '.svg'  = 'image/svg+xml'
  '.png'  = 'image/png'
  '.jpg'  = 'image/jpeg'
  '.jpeg' = 'image/jpeg'
  '.webp' = 'image/webp'
  '.gif'  = 'image/gif'
  '.ico'  = 'image/x-icon'
  '.woff' = 'font/woff'
  '.woff2' = 'font/woff2'
  '.ttf'  = 'font/ttf'
  '.mp3'  = 'audio/mpeg'
  '.ogg'  = 'audio/ogg'
  '.wav'  = 'audio/wav'
  '.glb'  = 'model/gltf-binary'
  '.gltf' = 'model/gltf+json'
  '.bin'  = 'application/octet-stream'
  '.wasm' = 'application/wasm'
}

# ---- pick a free port
$listener = $null
for ($p = $Port; $p -le $Port + 10; $p++) {
  try {
    $listener = [System.Net.Sockets.TcpListener]::new([System.Net.IPAddress]::Loopback, $p)
    $listener.Start()
    $Port = $p
    break
  } catch {
    $listener = $null
  }
}
if (-not $listener) {
  Write-Host "  No free port in $Port..$($Port + 10)." -ForegroundColor Red
  exit 1
}

$url = "http://localhost:$Port/?lang=fa"
Write-Host ''
Write-Host "  Shahr-e Farsh is running:  $url" -ForegroundColor Green
Write-Host '  keep this window open - press Ctrl+C to stop the game' -ForegroundColor DarkGray
Write-Host ''
try { Start-Process $url } catch { Write-Host "  (open $url yourself)" }

$sep = [System.IO.Path]::DirectorySeparatorChar
$rootFull = [System.IO.Path]::GetFullPath($web).TrimEnd([char[]]@('/', '\'))

try {
  while ($true) {
    $client = $listener.AcceptTcpClient()
    try {
      $client.NoDelay = $true
      $stream = $client.GetStream()
      $stream.WriteTimeout = 30000

      # Read the whole request header block. Browsers also open "preconnect" sockets that never send
      # anything, so we poll instead of blocking on ReadLine: an idle socket is dropped, never waited on.
      $buf = New-Object 'System.Collections.Generic.List[byte]'
      $limit = [DateTime]::UtcNow.AddMilliseconds(800)
      $done = $false
      while ([DateTime]::UtcNow -lt $limit) {
        if (-not $stream.DataAvailable) { Start-Sleep -Milliseconds 5; continue }
        $one = New-Object 'byte[]' 1
        $n = $stream.Read($one, 0, 1)
        if ($n -le 0) { break }
        $buf.Add($one[0])
        $c = $buf.Count
        if ($c -ge 2 -and $buf[$c-1] -eq 10) {
          if ($buf[$c-2] -eq 10 -or ($c -ge 4 -and $buf[$c-2] -eq 13 -and $buf[$c-3] -eq 10 -and $buf[$c-4] -eq 13)) {
            $done = $true; break
          }
        }
        if ($buf.Count -gt 65536) { $done = $true; break }
      }
      if (-not $done) { continue }

      $line  = [System.Text.Encoding]::ASCII.GetString($buf.ToArray()).Trim()
      $parts = $line -split ' '
      $raw   = if ($parts.Length -ge 2) { $parts[1] } else { '/' }

      $status = '200 OK'
      $ct = 'text/plain; charset=utf-8'
      $body = [System.Text.Encoding]::UTF8.GetBytes('Not found')

      if ($raw.Length -eq 0) { $raw = '/' }
      $q = $raw.IndexOf('?')
      if ($q -ge 0) { $raw = $raw.Substring(0, $q) }
      $q = $raw.IndexOf('#')
      if ($q -ge 0) { $raw = $raw.Substring(0, $q) }
      $rel = [System.Uri]::UnescapeDataString($raw).TrimStart('/')
      if ($rel -eq '' -or $rel.EndsWith('/')) { $rel = $rel + 'index.html' }
      $rel = ($rel -replace '/', $sep) -replace [regex]::Escape('\'), $sep

      $full = [System.IO.Path]::GetFullPath((Join-Path $rootFull $rel))
      $inside = $full.StartsWith($rootFull + $sep, [System.StringComparison]::OrdinalIgnoreCase) -or
                $full.Equals($rootFull, [System.StringComparison]::OrdinalIgnoreCase)
      if ($inside -and (Test-Path -LiteralPath $full -PathType Leaf)) {
        $ext = [System.IO.Path]::GetExtension($full).ToLower()
        if ($types.ContainsKey($ext)) { $ct = $types[$ext] }
        else { $ct = 'application/octet-stream' }
        $body = [System.IO.File]::ReadAllBytes($full)
        if ($script:ShowLog) { Write-Host "  200 $rel" -ForegroundColor DarkGray }
      } else {
        $status = '404 Not Found'
        $body = [System.Text.Encoding]::UTF8.GetBytes('Not found: ' + $rel)
        Write-Host "  404 $rel" -ForegroundColor DarkYellow
      }

      $head = "HTTP/1.1 $status`r`nContent-Type: $ct`r`nContent-Length: $($body.Length)`r`nCache-Control: no-cache`r`nConnection: close`r`n`r`n"
      $hb = [System.Text.Encoding]::ASCII.GetBytes($head)
      $stream.Write($hb, 0, $hb.Length)
      if ($parts[0] -ne 'HEAD') { $stream.Write($body, 0, $body.Length) }
      $stream.Flush()
      # Close politely. Closing a socket that still holds unread bytes makes Windows send a RST,
      # which can cut the response the browser is reading - so drain the input first.
      try { $client.Client.Shutdown([System.Net.Sockets.SocketShutdown]::Send) } catch { }
      $drain = [DateTime]::UtcNow.AddMilliseconds(100)
      while ([DateTime]::UtcNow -lt $drain -and $stream.DataAvailable) {
        $skip = New-Object 'byte[]' 4096
        if ($stream.Read($skip, 0, 4096) -le 0) { break }
      }
    } catch {
      # a tab closed mid-request: ignore and carry on
    } finally {
      try { $client.Close() } catch { }
    }
  }
} finally {
  $listener.Stop()
}
